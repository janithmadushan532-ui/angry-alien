export * from "./ParallaxConfig";
